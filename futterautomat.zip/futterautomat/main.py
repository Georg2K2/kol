"""
importiert Module, um:
 -die Eingabe-/Ausgabepins des RaspberryPi's,
 -Pausen nutzen zu können
 -sys und hx711 werden für das Auslesen der Wägezelle benötigt
"""
import RPi.GPIO as GPIO
import time
import sys
import smtplib
import os
from hx711 import HX711

def cleanAndExit():
    GPIO.cleanup()
    p.stop()
    server.quit()
    os.system("sudo shutdown -h now")
    print("Script wird beendet!")
    sys.exit()

def pausescript():
    check = False
    print("Das Script wurde pausiert!")
    while check == False:
        checkbutton = GPIO.input(13)
        if checkbutton == False:
            print("Script wird fortgesetzt!")
            GPIO.output(19, GPIO.HIGH)
            check = True
            
        time.sleep(0.5)
        GPIO.output(19, GPIO.LOW)
        time.sleep(1)
        GPIO.output(19, GPIO.HIGH)
    
def rotate(x):
    if x < 100:
        #klappe wird geöffnet
        print("Klappe auf!")
        p.ChangeDutyCycle(12.5)
        GPIO.output(19, GPIO.LOW)
    
        time.sleep(3)

        #klappe wird geschlossen
        print("Klappe zu!")
        p.ChangeDutyCycle(7.5)
        GPIO.output(19, GPIO.HIGH)
    
        time.sleep(1)
        p.ChangeDutyCycle(0.0)
    else:
        print("Der Futternapf ist voll!")

""" Mailserver initalisieren"""

server = smtplib.SMTP('smtp.gmail.com', 587)
server.starttls()
server.login("georg.grieger@gmail.com", "OVERall9371347")

"""hx711 initialisieren"""

hx = HX711(5, 6)
hx.set_reading_format("LSB", "MSB")
hx.set_reference_unit(388)
hx.reset()
hx.tare()
weiavg = 0

"""Servo initialisieren"""
#Pin 4 und 19 des GPIO aktivieren 
GPIO.setup(4,GPIO.OUT)
GPIO.setup(19, GPIO.OUT)
#GPIO 19 auf "HIGH" setzen, um LED anzuschalten
GPIO.output(19, GPIO.HIGH)

#Pin 13 aktivieren und als "pulled up" setzen
GPIO.setup(13, GPIO.IN, pull_up_down=GPIO.PUD_UP)

#Variable p als PWM Signal auf pin 7 gestartet, wellenlänge 50Hz
p = GPIO.PWM(4,50)

#PWM-Signal der Variable p (Pin 4) wird gestartet
p.start(7.5)

check = [1, 2, 3]
shutdown = True

while True:
    for i in range(3):
        try:
            for e in range(10):
                wei = hx.get_weight(5)
                weiavg += wei
                weiavg /= 2
            print("Aktueller Fuellstand:", weiavg, "g")
            rotate(weiavg)
			for f in range(0,1200):
				shutdown = GPIO.input(13)
				if shutdown == False:
					cleanAndExit()
				time.sleep(0.5)
            
			check[i] = weiavg/10
			if check[0] == check[1] == check[2] and weiavg < 100:
				server.sendmail("georg.grieger@gmail.com", "georg.grieger@gmail.com", "Der Füllstand des Katzenfütterungsroboters ist niedrig, oder es gibt einen Stau im Rohr!")
				server.sendmail("georg.grieger@gmail.com", "fhgrieger@aol.com", "Der Füllstand des Katzenfütterungsroboters ist niedrig, oder es gibt einen Stau im Rohr!")
				pausescript()

			time.sleep(5)

		except (KeyboardInterrupt, SystemExit):
			cleanAndExit()