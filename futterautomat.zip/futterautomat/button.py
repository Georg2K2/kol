import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)

GPIO.setup(13, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(19, GPIO.OUT)
GPIO.output(19, GPIO.HIGH)

check = False
print("Das Script wurde pausiert!")
while check == False:
    GPIO.output(19, GPIO.HIGH)
    print("licht an")
    checkbutton = GPIO.input(13)
    if checkbutton == False:
        print("Script wird fortgesetzt!")
        check = True
    time.sleep(0.5)
    GPIO.output(19, GPIO.LOW)
    print("licht aus")
    time.sleep(1)

print("ende")
